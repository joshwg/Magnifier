import tkinter as tk
from tkinter import Menu
from PIL import Image, ImageTk
import mss
import threading
import time


class MagnifierApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Desktop Magnifier")
        self.root.geometry("300x300")
        
        # Magnification settings
        self.magnification = 3.0
        self.running = True
        self.update_delay = 0.03  # ~30 fps
        
        # Create menu bar
        self.create_menu()
        
        # Create canvas for displaying magnified image
        self.canvas = tk.Canvas(root, bg='black', highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # Screen capture object (will be initialized in thread)
        self.sct = None
        
        # Bind window close event
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        
        # Start update thread
        self.update_thread = threading.Thread(target=self.update_magnifier, daemon=True)
        self.update_thread.start()
    
    def create_menu(self):
        """Create menu bar with magnification options"""
        menubar = Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Quit", command=self.on_closing)
        
        # Magnification menu
        mag_menu = Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Magnification", menu=mag_menu)
        
        # Add magnification levels from 2x to 20x
        for mag in range(2, 21):
            mag_menu.add_command(
                label=f"{mag}x",
                command=lambda m=mag: self.set_magnification(m)
            )
    
    def set_magnification(self, mag):
        """Set the magnification level"""
        self.magnification = float(mag)
        self.root.title(f"Desktop Magnifier - {mag}x")
    
    def get_mouse_position(self):
        """Get current mouse position"""
        return self.root.winfo_pointerx(), self.root.winfo_pointery()
    
    def capture_and_magnify(self):
        """Capture area around mouse and magnify it"""
        try:
            # Get current canvas size
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            
            if canvas_width <= 1 or canvas_height <= 1:
                return None
            
            # Get mouse position
            mouse_x, mouse_y = self.get_mouse_position()
            
            # Calculate capture area (area to capture before magnification)
            capture_width = int(canvas_width / self.magnification)
            capture_height = int(canvas_height / self.magnification)
            
            # Calculate capture region centered on mouse
            left = mouse_x - capture_width // 2
            top = mouse_y - capture_height // 2
            
            # Capture screenshot
            monitor = {
                "left": left,
                "top": top,
                "width": capture_width,
                "height": capture_height
            }
            
            screenshot = self.sct.grab(monitor)
            
            # Convert to PIL Image
            img = Image.frombytes("RGB", screenshot.size, screenshot.rgb)
            
            # Resize to canvas size (magnification)
            img = img.resize((canvas_width, canvas_height), Image.NEAREST)
            
            return img
        except Exception as e:
            print(f"Error capturing: {e}")
            return None
    
    def update_magnifier(self):
        """Continuously update the magnified view"""
        # Initialize mss in this thread (mss is not thread-safe)
        self.sct = mss.mss()
        
        try:
            while self.running:
                try:
                    img = self.capture_and_magnify()
                    if img:
                        # Convert to PhotoImage and update canvas
                        photo = ImageTk.PhotoImage(img)
                        self.canvas.delete("all")
                        self.canvas.create_image(0, 0, anchor=tk.NW, image=photo)
                        # Keep reference to prevent garbage collection
                        self.canvas.image = photo
                    
                    time.sleep(self.update_delay)
                except Exception as e:
                    print(f"Update error: {e}")
                    time.sleep(0.1)
        finally:
            # Clean up mss in the same thread where it was created
            if self.sct:
                try:
                    self.sct.close()
                except:
                    pass
    
    def on_closing(self):
        """Handle window close event"""
        self.running = False
        # Wait for update thread to finish and clean up
        if hasattr(self, 'update_thread') and self.update_thread.is_alive():
            self.update_thread.join(timeout=1.0)
        self.root.destroy()


def main():
    root = tk.Tk()
    app = MagnifierApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
